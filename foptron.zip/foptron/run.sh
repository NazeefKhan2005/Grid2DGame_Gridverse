#!/bin/bash
# FORTRON Game Launcher
# Compiles and runs the FORTRON game

clear

echo "╔═══════════════════════════════════════════╗"
echo "║    FORTRON - Grid Combat Challenge        ║"
echo "╚═══════════════════════════════════════════╝"
echo ""
echo "Compiling game..."

# Compile all Java files
javac -d bin -cp bin $(find src -name "*.java") 2>&1

if [ $? -eq 0 ]; then
    echo "✓ Compilation successful!"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "  GAME MECHANICS (Latest Update)"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "• JETWALL COLLISION:"
    echo "  - ALL jetwalls are deadly (including your own!)"
    echo "  - Enemies also take damage from any jetwall"
    echo "  - Enemy AI tries to avoid jetwalls based on difficulty"
    echo ""
    echo "• ENEMY AI LEVELS:"
    echo "  - Koura (EASY): Erratic, poor jetwall avoidance"
    echo "  - Sark (MEDIUM): Predictable, moderate avoidance"
    echo "  - Rinzler (HARD): Tactical, good avoidance"
    echo "  - Clu (IMPOSSIBLE): Brilliant, excellent avoidance"
    echo ""
    echo "• CONTROLS:"
    echo "  - Arrow Keys: Move player"
    echo "  - 1/2/3: Throw disc (range 1-3)"
    echo "  - P: Pause/Resume"
    echo ""
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""
    echo "Launching FORTRON..."
    echo ""
    
    # Run the game
    java -cp bin game.ui.GameWindow
else
    echo "✗ Compilation failed. Please check errors above."
    exit 1
fi
